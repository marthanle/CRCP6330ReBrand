# Pinterest+ — Customizable Quick Actions POC

> **Studio Assignment · Team of 3 · Pinterest enhancement, not a rebrand.**

Pinterest today gives every pin the same fixed row of quick actions — **Save**, a heart reaction, share, and a link icon — with high-frequency actions like **Download image** buried behind the three-dot ellipsis menu ([Pinterest Help — Interact with Pins](https://help.pinterest.com/en/article/interact-with-pins)). If you use Pinterest to build mood boards or grab reference images, you tap that ellipsis on every single pin.

**Pinterest+** is a POC of one focused enhancement: **let the user pick which 3–5 actions live on the pin's quick bar.** Download all day? Put it front and center. Never use reactions? Kick that button off the bar.

The POC includes a runnable Pinterest-style feed and a settings page where you drag/toggle which actions appear. All state persists in localStorage so it works with zero backend.

---

## What's in this repo

```
pinterest-plus/
├── README.md                     ← you are here
├── docs/
│   ├── 01-research.md            AI-assisted research + citations
│   ├── 02-concept.md             The customizable quick actions concept
│   ├── 03-spec.md                Full product spec + data model + API
│   ├── 04-phased-plan.md         3 phases + integration for a 3-person team
│   ├── 05-alt-ideas.md           Two additional enhancement ideas to pick from
│   └── 06-ai-prompts.md          Every prompt we used with AI
├── app/                          Next.js 14 (App Router) POC
│   ├── app/
│   │   ├── page.tsx              Redirects to /feed
│   │   ├── feed/page.tsx         Masonry feed with customizable quick actions
│   │   ├── settings/page.tsx     Pick which 3–5 actions to show
│   │   └── api/pins/route.ts     Serves seed pins as JSON
│   ├── components/               PinCard, QuickBar, ActionPicker, etc.
│   ├── lib/                      Types, action catalog, settings store
│   └── data/seed-pins.json       Seed content (Unsplash URLs, no auth needed)
└── public/
```

---

## Run it

**Requirements:** Node 20+, npm.

```bash
cd app
npm install
npm run dev
```

Open [http://localhost:3000](http://localhost:3000).

**What to try:**

1. `/feed` — hover any pin, see the quick action bar with the current 4 actions.
2. Click **Download image** directly on a pin — it downloads with no menu digging.
3. `/settings` — toggle actions on/off, reorder them, change the slot count (3–5).
4. Return to `/feed` — every pin now uses your new bar. Settings persist across refreshes (localStorage).

No environment variables, no accounts, no backend. Pure frontend POC that demonstrates the UX change.

---

## The three concept options (per assignment)

The team explored three enhancement directions before picking one. All three are documented so a grader (or the team next week) can see the alternatives considered:

1. **Customizable Quick Actions** *(this repo builds this one)* — [`docs/02-concept.md`](./docs/02-concept.md)
2. **Board-view layout switcher** *(alt idea)* — [`docs/05-alt-ideas.md#idea-2`](./docs/05-alt-ideas.md)
3. **"Set a default save board" global toggle** *(alt idea)* — [`docs/05-alt-ideas.md#idea-3`](./docs/05-alt-ideas.md)

Ideas 2 and 3 came directly from team discussion about Pinterest friction points; each is scoped so it could be the class-session build if the team pivots.

---

## Assignment checklist

- [x] Repo with meaningful commits (see git log).
- [x] Reviewed diff on the quick-actions PR (see [`docs/04-phased-plan.md § Integration`](./docs/04-phased-plan.md)).
- [x] Evidence of AI-assisted research ([`docs/01-research.md`](./docs/01-research.md), [`docs/06-ai-prompts.md`](./docs/06-ai-prompts.md)).
- [x] README with run instructions, expected output, and future work.
- [x] Comprehensive spec split into 3 phases + integration ([`docs/04-phased-plan.md`](./docs/04-phased-plan.md)).

---

## Future work

- **Persistent user accounts** so quick action prefs sync across devices (Supabase auth + Postgres).
- **Long-press context menu on mobile** with the same catalog + user prefs.
- **Analytics** — track which actions users promote so Pinterest could inform their global defaults.
- **A/B test hook** so half the users get their custom bar and half get today's fixed bar.
- Ship the two alternative enhancement ideas from `docs/05-alt-ideas.md` as follow-on features.
