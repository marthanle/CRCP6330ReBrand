'use client';

import type { ActionId, Pin } from '@/lib/types';
import { QuickBar } from './QuickBar';

type Props = {
  pin: Pin;
  order: ActionId[];
  onHide?: (id: string) => void;
};

export function PinCard({ pin, order, onHide }: Props) {
  return (
    <article className="pin">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={pin.imageUrl} alt={pin.title} loading="lazy" />
      <div className="pin-hover-scrim" />
      <QuickBar pin={pin} order={order} onHide={onHide} />
      <div className="meta">
        <p className="title">{pin.title}</p>
        <p className="creator">@{pin.creator.handle}</p>
      </div>
    </article>
  );
}
