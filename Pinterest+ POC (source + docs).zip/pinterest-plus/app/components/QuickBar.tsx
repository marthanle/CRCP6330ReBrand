'use client';

import { useState } from 'react';
import { ACTION_CATALOG, ALL_ACTIONS } from '@/lib/action-catalog';
import type { ActionId, Pin } from '@/lib/types';
import { Icon } from './Icon';
import { useToast } from './Toast';

type Props = {
  pin: Pin;
  order: ActionId[];
  onHide?: (id: string) => void;
};

const ELLIPSIS_ICON =
  'M5 12h.01M12 12h.01M19 12h.01M5 12a1 1 0 1 1-.001-.001M12 12a1 1 0 1 1-.001-.001M19 12a1 1 0 1 1-.001-.001';

export function QuickBar({ pin, order, onHide }: Props) {
  const toast = useToast();
  const [menuOpen, setMenuOpen] = useState(false);

  const run = async (id: ActionId) => {
    setMenuOpen(false);
    await ACTION_CATALOG[id].run({ pin, toast, hidePin: onHide });
  };

  return (
    <>
      <div className="quick-bar" onClick={(e) => e.stopPropagation()}>
        {order.map((id, idx) => {
          const def = ACTION_CATALOG[id];
          const isPrimary = idx === 0;
          return (
            <button
              key={id}
              className={`qa-btn ${isPrimary ? 'primary' : ''}`}
              title={def.label}
              aria-label={def.label}
              onClick={() => run(id)}
            >
              <Icon id={id} />
            </button>
          );
        })}
        <button
          className="qa-btn qa-ellipsis"
          title="More actions"
          aria-label="More actions"
          onClick={() => setMenuOpen((v) => !v)}
        >
          <svg viewBox="0 0 24 24" aria-hidden="true" style={{ width: 18, height: 18 }}>
            <circle cx="5" cy="12" r="1.5" fill="currentColor" />
            <circle cx="12" cy="12" r="1.5" fill="currentColor" />
            <circle cx="19" cy="12" r="1.5" fill="currentColor" />
          </svg>
        </button>
      </div>

      {menuOpen && (
        <div className="pop-menu" onClick={(e) => e.stopPropagation()}>
          {ALL_ACTIONS.map((id) => (
            <button key={id} onClick={() => run(id)}>
              <Icon id={id} />
              {ACTION_CATALOG[id].label}
              {order.includes(id) && (
                <span style={{ marginLeft: 'auto', fontSize: 11, color: '#999' }}>on bar</span>
              )}
            </button>
          ))}
        </div>
      )}
    </>
  );
}

// keep ELLIPSIS_ICON referenced (for consistency with other icons on future refactor)
export const _ELLIPSIS_ICON = ELLIPSIS_ICON;
