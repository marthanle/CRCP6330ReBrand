'use client';

import { createContext, useCallback, useContext, useEffect, useState } from 'react';

type ToastCtx = { push: (msg: string) => void };
const Ctx = createContext<ToastCtx>({ push: () => {} });

type Item = { id: number; msg: string };

export function ToastProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<Item[]>([]);

  const push = useCallback((msg: string) => {
    const id = Date.now() + Math.random();
    setItems((prev) => [...prev, { id, msg }]);
    setTimeout(() => setItems((prev) => prev.filter((i) => i.id !== id)), 2400);
  }, []);

  return (
    <Ctx.Provider value={{ push }}>
      {children}
      <div className="toast-stack">
        {items.map((i) => (
          <div key={i.id} className="toast" role="status">
            {i.msg}
          </div>
        ))}
      </div>
    </Ctx.Provider>
  );
}

export function useToast() {
  return useContext(Ctx).push;
}
