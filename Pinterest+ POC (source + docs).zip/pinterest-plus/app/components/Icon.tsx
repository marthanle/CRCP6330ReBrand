import type { ActionId } from '@/lib/types';
import { ACTION_CATALOG } from '@/lib/action-catalog';

export function Icon({ id, className }: { id: ActionId; className?: string }) {
  const def = ACTION_CATALOG[id];
  return (
    <svg className={className} viewBox="0 0 24 24" aria-hidden="true">
      <path d={def.iconPath} />
    </svg>
  );
}
