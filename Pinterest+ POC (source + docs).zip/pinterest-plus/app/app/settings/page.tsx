'use client';

import { useMemo } from 'react';
import { ACTION_CATALOG, ALL_ACTIONS, DEFAULT_SETTINGS, PRESETS } from '@/lib/action-catalog';
import { useQuickActionSettings } from '@/lib/use-settings';
import { Icon } from '@/components/Icon';
import { ToastProvider, useToast } from '@/components/Toast';
import type { ActionId, SlotCount } from '@/lib/types';

function Inner() {
  const [settings, setSettings, reset] = useQuickActionSettings();
  const toast = useToast();

  const activeSet = useMemo(() => new Set(settings.order), [settings.order]);
  const activeOrder = settings.order.slice(0, settings.slots);

  const setSlots = (n: SlotCount) => {
    let order = settings.order.slice();
    if (order.length > n) order = order.slice(0, n);
    setSettings({ ...settings, slots: n, order });
  };

  const removeAction = (id: ActionId) => {
    setSettings({ ...settings, order: settings.order.filter((x) => x !== id) });
  };

  const addAction = (id: ActionId) => {
    if (activeSet.has(id)) return;
    if (settings.order.length >= settings.slots) {
      toast(`Only ${settings.slots} slots — remove one first`);
      return;
    }
    setSettings({ ...settings, order: [...settings.order, id] });
  };

  const move = (idx: number, dir: -1 | 1) => {
    const j = idx + dir;
    if (j < 0 || j >= settings.order.length) return;
    const next = settings.order.slice();
    [next[idx], next[j]] = [next[j], next[idx]];
    setSettings({ ...settings, order: next });
  };

  const applyPreset = (name: keyof typeof PRESETS) => {
    setSettings(PRESETS[name]);
    toast(`Preset "${name}" applied`);
  };

  return (
    <div className="settings-wrap">
      <h1>Quick Actions</h1>
      <p className="lede">
        Pick which 3–5 actions live directly on every pin. The first slot is the primary
        (red) button. Everything else is still in the ⋯ overflow menu.
      </p>

      <section className="card">
        <h2>Number of slots</h2>
        <p className="sub">More slots = fewer trips to the ⋯ menu; fewer slots = a cleaner card.</p>
        <div className="slot-row">
          {[3, 4, 5].map((n) => (
            <button
              key={n}
              className={`slot-btn ${settings.slots === n ? 'active' : ''}`}
              onClick={() => setSlots(n as SlotCount)}
            >
              {n}
            </button>
          ))}
        </div>
      </section>

      <section className="card">
        <h2>Your quick bar ({activeOrder.length}/{settings.slots})</h2>
        <p className="sub">Reorder with the arrows; the top one is the primary action.</p>
        <div className="active-list">
          {activeOrder.map((id, idx) => (
            <div key={id} className="active-item">
              <Icon id={id} className="icon-inline" />
              <span className="grow">
                <strong>{ACTION_CATALOG[id].label}</strong>
                {idx === 0 && <span style={{ marginLeft: 8, fontSize: 11, color: '#e60023' }}>primary</span>}
              </span>
              <button aria-label="Move up" disabled={idx === 0} onClick={() => move(idx, -1)}>↑</button>
              <button aria-label="Move down" disabled={idx === activeOrder.length - 1} onClick={() => move(idx, 1)}>↓</button>
              <button aria-label="Remove" onClick={() => removeAction(id)}>✕</button>
            </div>
          ))}
          {activeOrder.length === 0 && (
            <p style={{ color: '#999' }}>No actions on your bar. Pick some below.</p>
          )}
        </div>
      </section>

      <section className="card">
        <h2>Available actions</h2>
        <p className="sub">Click to add. Grayed-out ones are already on your bar.</p>
        <div className="action-grid">
          {ALL_ACTIONS.map((id) => {
            const disabled = activeSet.has(id);
            return (
              <button
                key={id}
                className="action-tile"
                disabled={disabled}
                onClick={() => addAction(id)}
              >
                <Icon id={id} className="icon-inline" />
                {ACTION_CATALOG[id].label}
              </button>
            );
          })}
        </div>
      </section>

      <section className="card">
        <h2>Presets</h2>
        <p className="sub">Not sure? Start from a preset and tweak.</p>
        <div className="preset-row">
          <button className="preset-btn" onClick={() => applyPreset('creator')}>
            🎨 Creator
          </button>
          <button className="preset-btn" onClick={() => applyPreset('collector')}>
            📥 Collector
          </button>
          <button className="preset-btn" onClick={() => applyPreset('social')}>
            💬 Social
          </button>
          <button
            className="reset-btn"
            onClick={() => {
              reset();
              toast('Reset to defaults');
            }}
            style={{ marginLeft: 'auto' }}
          >
            Reset to defaults
          </button>
        </div>
      </section>

      <section className="card">
        <h2>Live preview</h2>
        <p className="sub">This is what a pin looks like with your current settings.</p>
        <div className="preview-card">
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img
            src="https://images.unsplash.com/photo-1520975916090-3105956dac38?w=800"
            alt="preview"
            style={{ width: '100%', height: '100%', objectFit: 'cover', display: 'block' }}
          />
          <div className="preview-bar">
            {activeOrder.map((id, idx) => (
              <span
                key={id}
                className={`qa-btn ${idx === 0 ? 'primary' : ''}`}
                title={ACTION_CATALOG[id].label}
              >
                <Icon id={id} />
              </span>
            ))}
            <span className="qa-btn qa-ellipsis" title="More actions">
              <svg viewBox="0 0 24 24" aria-hidden="true" style={{ width: 18, height: 18 }}>
                <circle cx="5" cy="12" r="1.5" fill="currentColor" />
                <circle cx="12" cy="12" r="1.5" fill="currentColor" />
                <circle cx="19" cy="12" r="1.5" fill="currentColor" />
              </svg>
            </span>
          </div>
        </div>
        <p className="sub" style={{ marginTop: 12 }}>
          Defaults today: {DEFAULT_SETTINGS.order.join(', ')}.
        </p>
      </section>
    </div>
  );
}

export default function SettingsPage() {
  return (
    <ToastProvider>
      <Inner />
    </ToastProvider>
  );
}
