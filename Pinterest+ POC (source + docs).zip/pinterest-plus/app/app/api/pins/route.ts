import { NextResponse } from 'next/server';
import pins from '@/data/seed-pins.json';

export async function GET() {
  return NextResponse.json({ pins });
}
