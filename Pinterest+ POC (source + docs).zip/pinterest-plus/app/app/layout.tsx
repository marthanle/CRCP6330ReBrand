import type { Metadata } from 'next';
import Link from 'next/link';
import './globals.css';

export const metadata: Metadata = {
  title: 'Pinterest+ — Customizable Quick Actions',
  description: 'A POC that lets users pick which quick actions appear on every pin.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <header className="topbar">
          <Link href="/feed" className="brand">
            <span className="brand-dot" />
            Pinterest<span className="brand-plus">+</span>
          </Link>
          <nav>
            <Link href="/feed">Feed</Link>
            <Link href="/settings">Settings</Link>
          </nav>
        </header>
        <main>{children}</main>
      </body>
    </html>
  );
}
