'use client';

import { useEffect, useState } from 'react';
import { PinCard } from '@/components/PinCard';
import { ToastProvider } from '@/components/Toast';
import { useQuickActionSettings } from '@/lib/use-settings';
import type { Pin } from '@/lib/types';

export default function FeedPage() {
  const [pins, setPins] = useState<Pin[]>([]);
  const [hidden, setHidden] = useState<Set<string>>(new Set());
  const [settings] = useQuickActionSettings();

  useEffect(() => {
    fetch('/api/pins')
      .then((r) => r.json())
      .then((d) => setPins(d.pins as Pin[]))
      .catch(() => setPins([]));
  }, []);

  const visiblePins = pins.filter((p) => !hidden.has(p.id));
  const activeOrder = settings.order.slice(0, settings.slots);

  return (
    <ToastProvider>
      <div className="feed-wrap">
        <div className="feed-header">
          <div>
            <h1>Your feed</h1>
            <p>Hover a pin to see your customized quick actions.</p>
          </div>
          <div style={{ fontSize: 13, color: '#666' }}>
            Bar: {activeOrder.length} slots · edit in{' '}
            <a href="/settings" style={{ textDecoration: 'underline' }}>Settings</a>
          </div>
        </div>

        {pins.length === 0 ? (
          <p style={{ color: '#888' }}>Loading pins…</p>
        ) : (
          <div className="masonry">
            {visiblePins.map((pin) => (
              <PinCard
                key={pin.id}
                pin={pin}
                order={activeOrder}
                onHide={(id) => setHidden((prev) => new Set(prev).add(id))}
              />
            ))}
          </div>
        )}
      </div>
    </ToastProvider>
  );
}
