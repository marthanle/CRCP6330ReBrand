export type ActionId =
  | 'save'
  | 'download'
  | 'share'
  | 'copyLink'
  | 'react'
  | 'send'
  | 'hide'
  | 'report'
  | 'note'
  | 'findSimilar';

export type Pin = {
  id: string;
  title: string;
  imageUrl: string;
  sourceUrl?: string;
  creator: { handle: string };
  width: number;
  height: number;
};

export type ToastFn = (message: string) => void;

export type ActionContext = {
  pin: Pin;
  toast: ToastFn;
  hidePin?: (id: string) => void;
};

export type ActionDef = {
  id: ActionId;
  label: string;
  /** Inline SVG path data (24x24 viewBox). */
  iconPath: string;
  run: (ctx: ActionContext) => void | Promise<void>;
};

export type SlotCount = 3 | 4 | 5;

export type QuickActionSettings = {
  slots: SlotCount;
  order: ActionId[];
  updatedAt: string;
};
