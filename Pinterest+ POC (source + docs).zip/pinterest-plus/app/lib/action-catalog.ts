import type { ActionDef, ActionId, QuickActionSettings } from './types';

// 24x24 icon paths (Feather / Lucide style).
const ICONS: Record<ActionId, string> = {
  save:
    'M6 3h12a1 1 0 0 1 1 1v17l-7-4-7 4V4a1 1 0 0 1 1-1z',
  download:
    'M12 3v12m0 0l-4-4m4 4l4-4M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2',
  share:
    'M4 12v7a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-7M16 6l-4-4-4 4M12 2v14',
  copyLink:
    'M10 14a5 5 0 0 0 7 0l3-3a5 5 0 0 0-7-7l-1 1M14 10a5 5 0 0 0-7 0l-3 3a5 5 0 0 0 7 7l1-1',
  react:
    'M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.5 1-1a5.5 5.5 0 0 0 0-7.8z',
  send:
    'M22 2L11 13M22 2l-7 20-4-9-9-4 20-7z',
  hide:
    'M17.9 17.9A10.4 10.4 0 0 1 12 20C5 20 1 12 1 12a20 20 0 0 1 4.2-5.9M9.9 4.2A10 10 0 0 1 12 4c7 0 11 8 11 8a20 20 0 0 1-3.2 4.7M1 1l22 22',
  report:
    'M4 22V4l16 8-16 8V4',
  note:
    'M4 4h13l3 3v13H4V4zm0 4h13M8 12h9M8 16h6',
  findSimilar:
    'M11 4a7 7 0 1 1 0 14 7 7 0 0 1 0-14zm10 17l-6-6',
};

const LABELS: Record<ActionId, string> = {
  save: 'Save',
  download: 'Download image',
  share: 'Share',
  copyLink: 'Copy link',
  react: 'React',
  send: 'Send to friend',
  hide: 'Hide pin',
  report: 'Report',
  note: 'Add note',
  findSimilar: 'Find similar',
};

async function triggerDownload(imageUrl: string, filename: string) {
  try {
    const res = await fetch(imageUrl, { mode: 'cors' });
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  } catch {
    // Fallback: open in new tab so the user can save manually.
    window.open(imageUrl, '_blank', 'noopener,noreferrer');
  }
}

export const ACTION_CATALOG: Record<ActionId, ActionDef> = {
  save: {
    id: 'save',
    label: LABELS.save,
    iconPath: ICONS.save,
    run: ({ toast }) => toast('Saved to your board'),
  },
  download: {
    id: 'download',
    label: LABELS.download,
    iconPath: ICONS.download,
    run: async ({ pin, toast }) => {
      toast('Downloading…');
      await triggerDownload(pin.imageUrl, `${pin.title.replace(/\s+/g, '-').toLowerCase()}.jpg`);
    },
  },
  share: {
    id: 'share',
    label: LABELS.share,
    iconPath: ICONS.share,
    run: async ({ pin, toast }) => {
      const url = pin.sourceUrl || window.location.href;
      const anyNav = navigator as unknown as { share?: (d: ShareData) => Promise<void> };
      if (anyNav.share) {
        try {
          await anyNav.share({ title: pin.title, url });
          return;
        } catch {
          /* user cancelled — fall through */
        }
      }
      await navigator.clipboard.writeText(url);
      toast('Link copied (share not supported here)');
    },
  },
  copyLink: {
    id: 'copyLink',
    label: LABELS.copyLink,
    iconPath: ICONS.copyLink,
    run: async ({ pin, toast }) => {
      const url = pin.sourceUrl || window.location.href;
      await navigator.clipboard.writeText(url);
      toast('Link copied');
    },
  },
  react: {
    id: 'react',
    label: LABELS.react,
    iconPath: ICONS.react,
    run: ({ toast }) => toast('❤️ Reacted'),
  },
  send: {
    id: 'send',
    label: LABELS.send,
    iconPath: ICONS.send,
    run: ({ toast }) => toast('Send flow (stub)'),
  },
  hide: {
    id: 'hide',
    label: LABELS.hide,
    iconPath: ICONS.hide,
    run: ({ pin, toast, hidePin }) => {
      hidePin?.(pin.id);
      toast('Pin hidden for this session');
    },
  },
  report: {
    id: 'report',
    label: LABELS.report,
    iconPath: ICONS.report,
    run: ({ toast }) => toast('Report submitted (stub)'),
  },
  note: {
    id: 'note',
    label: LABELS.note,
    iconPath: ICONS.note,
    run: ({ pin, toast }) => {
      const key = `pinterestPlus.note.${pin.id}`;
      const existing = localStorage.getItem(key) || '';
      const next = window.prompt(`Note for "${pin.title}"`, existing);
      if (next !== null) {
        localStorage.setItem(key, next);
        toast('Note saved');
      }
    },
  },
  findSimilar: {
    id: 'findSimilar',
    label: LABELS.findSimilar,
    iconPath: ICONS.findSimilar,
    run: ({ toast }) => toast('Finding similar pins (stub)'),
  },
};

export const ALL_ACTIONS: ActionId[] = Object.keys(ACTION_CATALOG) as ActionId[];

export const DEFAULT_SETTINGS: QuickActionSettings = {
  slots: 4,
  order: ['save', 'react', 'share', 'copyLink'],
  updatedAt: new Date(0).toISOString(),
};

export const PRESETS: Record<'creator' | 'collector' | 'social', QuickActionSettings> = {
  creator: {
    slots: 4,
    order: ['save', 'download', 'note', 'findSimilar'],
    updatedAt: new Date(0).toISOString(),
  },
  collector: {
    slots: 3,
    order: ['save', 'download', 'copyLink'],
    updatedAt: new Date(0).toISOString(),
  },
  social: {
    slots: 5,
    order: ['save', 'share', 'send', 'react', 'copyLink'],
    updatedAt: new Date(0).toISOString(),
  },
};
