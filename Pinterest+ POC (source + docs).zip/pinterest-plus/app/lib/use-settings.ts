'use client';

import { useCallback, useEffect, useState } from 'react';
import { DEFAULT_SETTINGS } from './action-catalog';
import type { QuickActionSettings } from './types';

const STORAGE_KEY = 'pinterestPlus.quickActions.v1';
const EVENT_NAME = 'pinterestPlus:settingsChange';

function readFromStorage(): QuickActionSettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_SETTINGS;
    const parsed = JSON.parse(raw) as QuickActionSettings;
    if (!parsed || !Array.isArray(parsed.order) || !parsed.slots) return DEFAULT_SETTINGS;
    return parsed;
  } catch {
    return DEFAULT_SETTINGS;
  }
}

function writeToStorage(s: QuickActionSettings) {
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(s));
    window.dispatchEvent(new CustomEvent(EVENT_NAME));
  } catch {
    /* localStorage may be disabled; caller still gets in-memory update */
  }
}

export function useQuickActionSettings(): [
  QuickActionSettings,
  (next: QuickActionSettings) => void,
  () => void,
] {
  const [settings, setSettings] = useState<QuickActionSettings>(DEFAULT_SETTINGS);

  useEffect(() => {
    setSettings(readFromStorage());
    const onChange = () => setSettings(readFromStorage());
    window.addEventListener(EVENT_NAME, onChange);
    window.addEventListener('storage', onChange);
    return () => {
      window.removeEventListener(EVENT_NAME, onChange);
      window.removeEventListener('storage', onChange);
    };
  }, []);

  const update = useCallback((next: QuickActionSettings) => {
    const stamped = { ...next, updatedAt: new Date().toISOString() };
    setSettings(stamped);
    writeToStorage(stamped);
  }, []);

  const reset = useCallback(() => {
    update(DEFAULT_SETTINGS);
  }, [update]);

  return [settings, update, reset];
}
