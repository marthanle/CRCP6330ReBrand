# 05 · Two Additional Enhancement Ideas

Explored alongside the customizable quick actions bar. Each is scoped small enough to be the class-session build if the team wants to pivot. Each includes: the friction, the fix, why it's tractable, and a 3-phase split.

---

## Idea 2 — **Board-view layout switcher**

### The friction

Every Pinterest board renders in the same masonry grid regardless of what's on it. A board of 50 outfits is browsable in masonry. A board of 12 room designs the user is comparing side-by-side is not — the varied crop heights make comparisons hard. Recipes might be better as a compact list with titles visible.

### The fix

A layout toggle at the top of each board with three options:

- **Masonry** (today's default)
- **Grid** (uniform square crops, 4 per row on desktop)
- **List** (thumbnail + title + tags on one row — great for recipes/articles)

Selected layout persists per board (`localStorage: pinterestPlus.boardLayout[boardId]`).

### Why it's tractable in one class session

- Zero new backend. Same pin data, different CSS.
- The three layouts are each ~15 lines of CSS.
- No new data model beyond `boardId → layout` in localStorage.

### 3-phase split

1. **Feed & board scaffold** (Dev A): a `/board/:id` route with sample data and the masonry default.
2. **Layout components** (Dev B): `MasonryLayout.tsx`, `GridLayout.tsx`, `ListLayout.tsx` — each takes `pins: Pin[]` and renders.
3. **Toggle + persistence** (Dev C): the header switcher, localStorage store, plumb the selection into the board page.

---

## Idea 3 — **"Set a default save board" global toggle**

### The friction

Pinterest picks the "recommended" board every time you save a pin. Power users nearly always want the same board (e.g. an ongoing project). Today, per Pinterest's own help pages, there is no single global toggle to override this default — you have to use the dropdown on every save.

### The fix

Add a **Settings → Saving** page with one toggle:

- **Default save board**: `[None (use recommendations)] / [Pick a board ▾]`

When set, the Save button on every pin saves directly to that board with no prompt (still shows a toast with an "Undo" that lets you re-pick).

### Why it's tractable in one class session

- One setting, one UI component in Settings, one hook (`useDefaultBoard()`) that `PinCard` reads.
- Composes nicely with Idea 1 — Save is already on the quick bar; this just changes its destination.

### 3-phase split

1. **Boards data + picker component** (Dev A): mock board list, `BoardPicker` component.
2. **Settings page + storage** (Dev B): the toggle UI, `useDefaultBoard` hook.
3. **Wire Save behavior** (Dev C): update the `save` handler in the action catalog to read the default and skip the prompt when set. Toast with Undo.

---

## Why we're building Idea 1 first

Ideas 1 and 3 both touch **user preferences** — Idea 1 sets a strong pattern (`Settings → X` with a `use<X>()` hook + localStorage) that Idea 3 can piggyback on next class. Idea 2 is orthogonal and can be the *third* week's build.

Order of implementation (rough):

- **This class session:** Idea 1 — customizable quick actions.
- **Next class session:** Idea 3 — default save board (reuses the settings pattern from Idea 1).
- **Third class session:** Idea 2 — board-view layout switcher (reuses the PinCard + layout components from Idea 1).

Doing them in this order means each week's work compounds instead of scattering.
