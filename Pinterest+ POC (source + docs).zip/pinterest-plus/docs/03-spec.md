# 03 · Product Spec

## Scope

Class-session MVP: a runnable POC that demonstrates customizable quick actions end-to-end on the web. No auth, no backend beyond a JSON endpoint serving seed pins.

---

## Information architecture

```
/                    Redirects to /feed
/feed                Masonry grid of pins with quick action bar on hover
/settings            Pick 3–5 actions, reorder them, choose a preset
```

## Data model

```ts
// The full catalog of available actions (defined statically in code)
type ActionId =
  | 'save'
  | 'download'
  | 'share'
  | 'copyLink'
  | 'react'
  | 'send'
  | 'hide'
  | 'report'
  | 'note'
  | 'findSimilar';

type ActionDef = {
  id: ActionId;
  label: string;      // "Download image"
  icon: string;       // inline SVG name
  handler: (pin: Pin) => void | Promise<void>;
};

// User settings persisted to localStorage
type QuickActionSettings = {
  slots: 3 | 4 | 5;
  order: ActionId[];  // length must equal slots
  updatedAt: string;  // ISO
};

// A pin (subset used in POC)
type Pin = {
  id: string;
  title: string;
  imageUrl: string;
  sourceUrl?: string;
  creator: { handle: string };
  width: number;
  height: number;
};
```

Default settings (matches Pinterest's current visible actions roughly):

```ts
const DEFAULT_SETTINGS: QuickActionSettings = {
  slots: 4,
  order: ['save', 'react', 'share', 'copyLink'],
  updatedAt: new Date().toISOString(),
};
```

Presets available in Settings:

- **Creator**: `['save', 'download', 'note', 'findSimilar']`
- **Collector**: `['save', 'download', 'copyLink']` (3 slots)
- **Social**: `['save', 'share', 'send', 'react', 'copyLink']` (5 slots)

## The catalog (all 10 actions)

| ID | Label | Behavior in POC |
| --- | --- | --- |
| `save` | Save | Toasts "Saved to board" |
| `download` | Download image | Triggers browser download of the pin image |
| `share` | Share | Opens native `navigator.share` if available, else toast |
| `copyLink` | Copy link | Writes pin URL to clipboard, toast |
| `react` | React | Toggles a heart state on the pin |
| `send` | Send to friend | Toasts "Send flow (stub)" |
| `hide` | Hide pin | Removes the pin from the current feed session |
| `report` | Report | Toasts "Report submitted (stub)" |
| `note` | Add note | Opens a small textarea popover, saves to localStorage per-pin |
| `findSimilar` | Find similar | Toasts "Finding similar pins (stub)" |

## Settings page — UX

- **Slot count selector** (3 / 4 / 5) at the top.
- **Active actions list** — the currently-selected actions in display order. Each has ✕ (remove) and ↕ drag handle.
- **Available actions grid** — everything not currently active. Click to add (respects slot cap).
- **Presets row** — three preset buttons. Clicking one replaces the current selection with a warning toast ("preset applied, click Undo to revert").
- **Reset to default** button.
- **Live preview** — a mock pin card at the bottom shows the bar as configured.

Settings persist to `localStorage` under `pinterestPlus.quickActions.v1`.

## Feed page — UX

- Full-width masonry grid via CSS `columns` (no JS layout library).
- Hover a pin → the quick bar fades in at the bottom.
- Bar shows exactly `settings.slots` icon-buttons in `settings.order`. Every button has a tooltip.
- Ellipsis (⋯) button on the far right still opens a menu with **all** actions (even ones already on the bar) — this is the safety net.
- Toast component renders in bottom-left.

## API

```
GET /api/pins  →  { pins: Pin[] }
```

Serves `data/seed-pins.json`. In the POC there is no POST/PUT — settings live in localStorage, and actions like `save` are stubs.

## Non-functional

- All colors WCAG AA against pin backgrounds (the bar has a semi-opaque scrim behind it).
- Keyboard: Tab reaches each visible button; Enter activates. Ellipsis menu is keyboard-navigable.
- No layout shift on hover — the bar overlays, doesn't push content.
- localStorage failures fall back to defaults without crashing.

## Out of scope for POC

Auth, real backend, mobile long-press, Pinterest API integration, telemetry, A/B framework, cross-device sync.
