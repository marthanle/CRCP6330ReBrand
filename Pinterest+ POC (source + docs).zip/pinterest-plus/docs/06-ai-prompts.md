# 06 · AI Prompts Log

Evidence of how AI was used during research and design.

---

## Research-phase queries (Perplexity Computer web search)

1. `Pinterest pin quick actions bar like save share download`
2. `Pinterest customize quick actions feature request`
3. `Pinterest download image button hidden three dots`
4. `Pinterest hover pin buttons what actions`
5. `Pinterest user feedback missing features 2024 2025`
6. `customizable action bar UX pattern mobile apps`

## Extraction prompt against Pinterest Help

Fetched: https://help.pinterest.com/en/article/interact-with-pins

Prompt:

> List every action you can take on a Pin. Which are one-click (visible on the pin) vs hidden behind the ellipsis menu? Distinguish desktop web vs mobile.

The structured response drove the tables in [`01-research.md`](./01-research.md).

---

## Design-phase prompt

> "Pinterest hardcodes 4 quick actions on every pin and hides Download behind ⋯. Design a settings UX that lets users pick 3–5 actions from a catalog of 10, with sensible presets, that a 3-person student team could ship in a 2-hour class session. Include: page layout, storage strategy, default behavior, and how to keep first-run identical to Pinterest today."

Response distilled into [`03-spec.md`](./03-spec.md) and the presets defined in `app/lib/action-catalog.ts`.

---

## Working rule of thumb

We used AI to:

1. **Confirm the current state** (what Pinterest actually does today).
2. **Find precedent** (iOS Control Center, macOS toolbar, Slack).
3. **Pressure-test the scope** ("can 3 devs ship this in 2 hours?").

We did **not** use AI to:

- Write the final code (that's for the team, per the assignment).
- Generate any content that would land in the app itself.
