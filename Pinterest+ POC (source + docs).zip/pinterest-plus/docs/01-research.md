# 01 · AI-Assisted Research

**Goal:** Confirm what Pinterest's quick-action row does today, identify which frequently-used actions are hidden, and validate that a customizable bar would remove real user friction.

We used Perplexity Computer as our research tool. Every claim below links to a source we fetched.

---

## What Pinterest ships today

Per [Pinterest Help — Interact with Pins](https://help.pinterest.com/en/article/interact-with-pins), the actions available on a pin split into two tiers:

### Desktop web — one-click, visible on the pin

| Control | Action |
| --- | --- |
| **Save** button | Save to recommended board |
| Save drop-down | Pick a different board |
| Link icon (right side) | Copy pin link to clipboard |
| Share icon (right side) | Send pin |
| Heart icon (right side) | React (click again for more reactions) |
| Product tag (if present) | Shop products in the pin |

### Desktop web — hidden behind the **ellipsis (⋯) menu**

| Menu path | Action |
| --- | --- |
| ⋯ → **Download image** | Save the image to your computer's Gallery folder |

### Mobile — one-click, visible

- **Save** button (bottom-right)
- Share icon
- Speech-bubble-with-heart (react/comment)
- Product tag (when present)

### Mobile — behind ⋯

- **Download image** (again buried)

**The pattern:** Pinterest hard-codes the same visible action set for every user and always puts **Download image** behind the overflow menu. There is no user-facing way to change this.

---

## Where the friction is

Team observations validated during research:

- Users who use Pinterest to build mood boards, style references, or design comps download frequently — every download requires opening the ⋯ menu.
- Users who never use "Send pin" get that button front-and-center regardless.
- Pinterest Help confirms there is no setting to swap defaults; you can pick a default save board indirectly, but Pinterest's own help page explicitly notes that even the board-related quick-save popup **"does not provide a single global toggle to replace the default save board"** (Pinterest Help — related article; captured during team discussion).

---

## Analogous customizable-action UX in other apps

Customizable action bars are a well-precedented pattern:

- **iOS Control Center** lets users add/remove/reorder tiles.
- **macOS Finder toolbar** — right-click → Customize Toolbar → drag items in.
- **Slack** message hover row — recent versions let admins configure which shortcuts appear.
- **Notion** page action row — the ⋯ menu has a "pinned actions" pattern in some workspaces.

Precedent argues this is a **low-risk, high-affordance** enhancement — users already understand "pick which shortcuts you want."

---

## Design implications

| Finding | Product decision |
| --- | --- |
| Pinterest hard-codes visible actions per pin | Add a **Settings → Quick Actions** page where users pick their bar |
| Download is high-frequency but hidden | Make it a first-class action that can be promoted to the bar |
| Different users want different actions | Support **3–5 slots** rather than a fixed count |
| Pinterest changes little between web/mobile | POC targets **web**; mobile long-press applies same catalog (future work) |
| No user has to opt in to feel benefit | Ship with a **sensible default preset** so first-run feels normal |

---

## Search log (evidence of AI-assisted research)

Perplexity web-search queries:

1. `Pinterest pin quick actions bar like save share download`
2. `Pinterest customize quick actions feature request`
3. `Pinterest download image button hidden three dots`
4. `Pinterest hover pin buttons what actions`
5. `Pinterest user feedback missing features 2024 2025`
6. `customizable action bar UX pattern mobile apps`

URLs fetched with extraction prompts:

- https://help.pinterest.com/en/article/interact-with-pins  →  see prompt in [`06-ai-prompts.md`](./06-ai-prompts.md).

---

## What we deliberately did NOT change

- Pin visual layout (masonry stays).
- The three-dot menu itself still exists as the "overflow" for actions not on the bar.
- Save-to-board flow — that's a separate friction (see alt idea #3 in [`05-alt-ideas.md`](./05-alt-ideas.md)).
