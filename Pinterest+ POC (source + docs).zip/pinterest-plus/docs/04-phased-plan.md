# 04 · Phased Implementation Plan (Team of 3 + Integration)

**Time budget:** one class session (~2 hours of build).

Everyone works on their own branch off `main`. Integration is a scheduled 20-minute merge window at the end.

---

## Phase 1 — **Feed + PinCard + static Quick Bar** *(Developer A)*

**Owner deliverable:** `/feed` renders a masonry grid of seed pins. Hover shows a **static** 4-slot quick bar (Save, React, Share, Copy link). All actions wired to toasts so they're demoable.

**Files owned:**

- `app/app/feed/page.tsx`
- `app/components/PinCard.tsx`
- `app/components/QuickBar.tsx`
- `app/components/Toast.tsx`
- `app/data/seed-pins.json`
- `app/app/api/pins/route.ts`

**Definition of done:**

1. `/feed` shows 20+ pins in a responsive masonry.
2. Hover a pin → quick bar animates in.
3. Each button has an icon, tooltip, and working handler (toasts are fine).
4. Ellipsis (⋯) opens a menu listing **all 10 catalog actions**.
5. ≥ 2 commits, PR opened.

**Depends on:** nothing.

---

## Phase 2 — **Action Catalog + Settings Store** *(Developer B)*

**Owner deliverable:** The single source of truth for actions (`lib/action-catalog.ts`) and the localStorage-backed settings store (`lib/settings-store.ts`). Also a small `useQuickActionSettings()` React hook that Phase 1's `QuickBar` will consume in the integration phase.

**Files owned:**

- `app/lib/types.ts`
- `app/lib/action-catalog.ts`
- `app/lib/settings-store.ts`
- `app/lib/use-settings.ts`

**Definition of done:**

1. Catalog exports all 10 `ActionDef` objects with icons + handlers.
2. Store: `getSettings()`, `setSettings()`, `resetToDefault()`, `applyPreset(name)`.
3. Hook: `useQuickActionSettings()` → `[settings, updateSettings]` with SSR-safe defaults.
4. Handlers that need pin data receive `(pin: Pin)`; those needing DOM APIs (clipboard, download) work in the browser only.
5. Unit-friendly: catalog + store have no React deps (importable from anywhere).
6. ≥ 2 commits, PR opened.

**Depends on:** the `Pin` and `ActionId` types in `lib/types.ts` — Phase 2 owns them. Phase 1 imports the type only.

**Agreed interface with Phase 1 & 3:**

```ts
export const ACTION_CATALOG: Record<ActionId, ActionDef>;
export function useQuickActionSettings(): [QuickActionSettings, (s: QuickActionSettings) => void];
export const PRESETS: Record<'creator' | 'collector' | 'social', QuickActionSettings>;
```

---

## Phase 3 — **Settings Page: picker, reorder, presets, live preview** *(Developer C)*

**Owner deliverable:** `/settings` page where users pick which 3–5 actions appear on their quick bar, in what order.

**Files owned:**

- `app/app/settings/page.tsx`
- `app/components/ActionPicker.tsx`
- `app/components/SlotSelector.tsx`
- `app/components/PresetRow.tsx`
- `app/components/LivePreview.tsx`

**Definition of done:**

1. Slot count selector (3/4/5).
2. Active actions shown in order with remove + reorder controls (↑/↓ buttons OK; drag-and-drop is stretch).
3. Available actions grid; click to add (disabled at slot cap).
4. Three preset buttons apply presets from Phase 2 with an Undo toast.
5. "Reset to defaults" button.
6. Live preview updates in real time.
7. ≥ 2 commits, PR opened.

**Depends on:** Phase 2's `useQuickActionSettings` hook and `ACTION_CATALOG`.

---

## Integration phase — **Merge, wire up, smoke test** *(all 3, ~20 min)*

**Order of merges:**

1. **Phase 2** (`feature/catalog-store`) → `main`. Types now exist for everyone.
2. **Phase 1** (`feature/feed`) → `main`. Rebases onto Phase 2 to import the shared types.
3. **Phase 3** (`feature/settings`) → `main`.
4. **Integration commit on `main`:** rewire `QuickBar` in `PinCard` to read from `useQuickActionSettings()` instead of the hardcoded array. This is a ~5-line change.

**Smoke test checklist:**

- [ ] `npm run dev` starts cleanly.
- [ ] `/` redirects to `/feed`.
- [ ] `/feed` shows pins, hover → bar with 4 default actions.
- [ ] Click **Download image** in the ⋯ menu → file downloads.
- [ ] Go to `/settings`, change slot count to 3, drop Share, keep Download.
- [ ] Return to `/feed` — bar now has 3 slots, Download visible on every pin.
- [ ] Refresh browser — settings persist.
- [ ] `Reset to defaults` restores the original bar.
- [ ] README screenshot added.

**Commit hygiene:**

- One squash-merge PR per phase.
- Final commit on `main`: `chore(v0.1): demo-ready POC`.

**Reviewed diff evidence** (assignment requirement): each PR gets a second team member as reviewer; leave at least one inline comment per PR before merging.

---

## Risk register

| Risk | Mitigation |
| --- | --- |
| Phase 1 hardcodes actions and diverges from Phase 2's catalog | Interface pinned in Phase 2 section above; Phase 1 imports the type from day one |
| Drag-and-drop reorder takes too long | Fallback ↑/↓ buttons are the required behavior; drag is stretch |
| Download works differently across browsers | Use `<a download>` on same-origin blob; document Safari quirks in code comment |
| Merge conflicts in `PinCard.tsx` | Only Phase 1 owns it during the session; integration wire-up is a 5-line, non-conflicting change |
| localStorage disabled by user | Fall back to in-memory settings, show a toast explaining prefs won't persist |

---

## Post-class stretch

- Ship one of the alt ideas in [`05-alt-ideas.md`](./05-alt-ideas.md).
- Add per-preset icons and animations.
- Analytics: log which actions users promote (would inform Pinterest's global defaults).
- Deploy to Vercel and share the URL with the class.
