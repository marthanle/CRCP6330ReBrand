# 02 · Concept: Customizable Quick Actions

## One-liner

**Let every Pinterest user pick which 3–5 quick actions appear directly on the pin, instead of Pinterest hard-coding the same set for everyone.**

## The moment we're improving

Today, on Pinterest desktop, every pin hover shows the same fixed row: Save, a heart, share, and a link icon. **Download image** — one of the most requested actions for people using Pinterest as a reference tool — sits behind the three-dot ellipsis menu ([Pinterest Help](https://help.pinterest.com/en/article/interact-with-pins)). That's an extra click on *every single download.*

## The change

Add a **Settings → Quick Actions** page. The user:

1. Sees a catalog of ~10 actions (Save, Download, Share, Copy link, React, Send to friend, Hide, Report, Add note, Find similar).
2. Picks between **3 and 5** to appear on every pin's quick bar.
3. Drags to reorder them.
4. Optionally chooses a preset ("Creator", "Collector", "Casual browser").

The pin's ellipsis (⋯) still shows every action, so nothing is ever *hidden* — the bar just surfaces what *you* use most.

## Why this is the right first enhancement

- **Small, testable, high-impact.** A single feature, isolated to the pin card and one settings page. Perfect for a class-session build.
- **Zero risk to existing users.** Defaults match Pinterest's current bar, so any user who never visits Settings sees no change.
- **Personalization ≠ AI.** No model needed, no training data, no ethics review. Pure product design.
- **Precedent exists.** iOS Control Center, macOS toolbar, Slack shortcuts — customizable action rows are a solved UX pattern.

## Personas

**"The Collector" — Rosa, 27, interior designer.**
Downloads 30–50 reference images per project. Wants Download in slot #1. Never sends pins to friends.

**"The Curator" — Devon, 22, film student.**
Builds mood boards, shares them with a group chat. Wants Save + Share + Copy link on the bar; doesn't care about reactions.

**"The Casual Browser" — Meg, 41.**
Scrolls Pinterest before bed for recipe ideas. Happy with today's defaults. Never opens Settings. Sees no change.

## Non-goals

- Not changing the pin's visual design.
- Not touching the ellipsis menu — it stays as the full-catalog fallback.
- Not addressing the "default save board" problem (that's alt idea #3).
- Not building mobile in the POC (web only; the same catalog would drive mobile long-press).

## Success metrics (if Pinterest shipped this)

- % of users who visit `/settings/quick-actions` in the first 30 days.
- % of users who change from the default.
- Reduction in taps-per-download for users who add Download to their bar (target: 50%).
- Retention delta between users who customize vs. those who don't.
