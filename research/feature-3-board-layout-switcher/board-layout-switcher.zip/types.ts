export interface Pin {
  id: string;
  imageUrl: string;
  title: string;
  tags?: string[];
  createdAt?: string; // used by Feature 2's chronological sort — shared dataset
  following?: boolean; // used by Feature 2 — whether pin's source is followed
}
