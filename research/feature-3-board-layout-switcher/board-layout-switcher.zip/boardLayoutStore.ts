/**
 * Persistence for Feature 3 (Board-View Layout Switcher).
 *
 * IMPORTANT: this must read/write the SAME localStorage key that Feature 1
 * (Customizable Quick Actions) uses, per the spec's Cross-Feature Decision —
 * one shared JSON blob, not two competing storage schemes.
 *
 * Confirm the exact key name + shape with whoever builds Feature 1 before
 * merging — this file assumes a key of "sourced-settings" and a
 * `boardLayouts` sub-object, but adjust to match whatever Feature 1 lands on.
 */

export type BoardLayoutMode = "masonry" | "grid" | "list";

const STORAGE_KEY = "sourced-settings"; // TODO (Steve): confirm shared key name
const DEFAULT_LAYOUT: BoardLayoutMode = "masonry";

interface SourcedSettings {
  boardLayouts?: Record<string, BoardLayoutMode>;
  // ...other shared settings (e.g. Feature 1's quick-actions selection) live
  // alongside this in the same blob — don't overwrite the whole object below.
  [key: string]: unknown;
}

function readSettings(): SourcedSettings {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    const parsed = JSON.parse(raw);
    return typeof parsed === "object" && parsed !== null ? parsed : {};
  } catch {
    // Corrupted/unavailable storage — fall back to empty, per spec's
    // "fall back to defaults rather than rendering nothing" rule.
    return {};
  }
}

function writeSettings(settings: SourcedSettings): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(settings));
  } catch {
    // Storage unavailable (private browsing, quota, etc.) — fail silently.
    // Layout choice just won't persist this session.
  }
}

export function getBoardLayout(boardId: string): BoardLayoutMode {
  const settings = readSettings();
  return settings.boardLayouts?.[boardId] ?? DEFAULT_LAYOUT;
}

export function setBoardLayout(boardId: string, mode: BoardLayoutMode): void {
  const settings = readSettings();
  settings.boardLayouts = { ...settings.boardLayouts, [boardId]: mode };
  writeSettings(settings);
}
