import { useState, useEffect } from "react";
import { getBoardLayout, setBoardLayout, BoardLayoutMode } from "./boardLayoutStore";
import { MasonryView } from "./views/MasonryView";
import { GridView } from "./views/GridView";
import { ListView } from "./views/ListView";
import type { Pin } from "./types";

interface BoardLayoutSwitcherProps {
  boardId: string;
  pins: Pin[];
}

const LAYOUT_OPTIONS: { mode: BoardLayoutMode; label: string; icon: string }[] = [
  { mode: "masonry", label: "Masonry", icon: "▦" }, // swap for real icons (e.g. lucide-react)
  { mode: "grid", label: "Grid", icon: "▢" },
  { mode: "list", label: "List", icon: "☰" },
];

/**
 * Feature 3 — Board-View Layout Switcher
 * Per-board layout toggle (masonry / grid / list) over one shared pin dataset.
 * Persists selection per boardId in the shared local settings store
 * (same store as Feature 1's quick-actions config — see boardLayoutStore.ts).
 */
export function BoardLayoutSwitcher({ boardId, pins }: BoardLayoutSwitcherProps) {
  const [layout, setLayout] = useState<BoardLayoutMode>("masonry");

  // Load this board's stored layout on mount / when boardId changes
  useEffect(() => {
    setLayout(getBoardLayout(boardId));
  }, [boardId]);

  function handleChange(mode: BoardLayoutMode) {
    // TODO (Steve): preserve scroll position across the switch —
    // capture window.scrollY before setLayout, restore after render.
    // See spec "Edge Cases: Switching layout mid-scroll".
    setBoardLayout(boardId, mode);
    setLayout(mode);
  }

  return (
    <div className="board-page">
      <div
        className="board-layout-toggle"
        role="tablist"
        aria-label="Board layout"
      >
        {LAYOUT_OPTIONS.map((opt) => (
          <button
            key={opt.mode}
            role="tab"
            aria-selected={layout === opt.mode}
            className={layout === opt.mode ? "active" : ""}
            onClick={() => handleChange(opt.mode)}
          >
            <span aria-hidden="true">{opt.icon}</span> {opt.label}
          </button>
        ))}
      </div>

      {/* TODO (Steve): each of these three components reads the SAME `pins`
          array — no data transformation happens here, only presentation.
          See spec Edge Cases for the 0-2 pin / long-title / breakpoint
          requirements each view must handle internally. */}
      {layout === "masonry" && <MasonryView pins={pins} />}
      {layout === "grid" && <GridView pins={pins} />}
      {layout === "list" && <ListView pins={pins} />}
    </div>
  );
}
