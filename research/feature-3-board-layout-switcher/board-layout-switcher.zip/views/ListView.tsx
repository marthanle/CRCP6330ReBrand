import type { Pin } from "../types";

interface ListViewProps {
  pins: Pin[];
}

/**
 * Thumbnail + title + tags, one row per pin.
 *
 * TODO (Steve):
 * - Truncate long titles at 2 lines with ellipsis (CSS `line-clamp: 2` +
 *   `-webkit-box-orient: vertical` + `overflow: hidden`) rather than letting
 *   text overflow and break row height. See spec Edge Cases.
 */
export function ListView({ pins }: ListViewProps) {
  return (
    <div className="board-list">
      {pins.map((pin) => (
        <div key={pin.id} className="board-list__row">
          <img
            src={pin.imageUrl}
            alt={pin.title}
            className="board-list__thumb"
            loading="lazy"
          />
          <div className="board-list__meta">
            <div className="board-list__title">{pin.title}</div>
            <div className="board-list__tags">
              {pin.tags?.map((tag) => (
                <span key={tag} className="board-list__tag">
                  {tag}
                </span>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
