import type { Pin } from "../types";

interface GridViewProps {
  pins: Pin[];
}

/**
 * Uniform square-crop grid. 4/row desktop, 2/row under ~600px
 * (drop to 1 column if crops get illegibly small at that breakpoint —
 * verify visually per spec before locking in 2 vs 1).
 *
 * TODO (Steve):
 * - CSS: `object-fit: cover` on each pin image, aspect-ratio: 1.
 * - Edge case — 0-2 pins: don't stretch a partial row full-width.
 *   Suggest wrapping in a flex container with `justify-content: flex-start`
 *   instead of a strict grid when pins.length <= 2, OR use CSS grid with
 *   `grid-auto-flow` + fixed column width so a short row doesn't stretch.
 */
export function GridView({ pins }: GridViewProps) {
  const isSparse = pins.length <= 2; // triggers the no-stretch layout path

  return (
    <div className={`board-grid ${isSparse ? "board-grid--sparse" : ""}`}>
      {pins.map((pin) => (
        <div key={pin.id} className="board-grid__item">
          <img src={pin.imageUrl} alt={pin.title} loading="lazy" />
        </div>
      ))}
    </div>
  );
}
