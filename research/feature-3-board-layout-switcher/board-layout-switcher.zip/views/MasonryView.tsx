import type { Pin } from "../types";

interface MasonryViewProps {
  pins: Pin[];
}

/**
 * Masonry is today's existing default behavior — this is a passthrough
 * stub. TODO (Steve): replace this body with whatever the current board
 * page already renders for masonry (don't rebuild it — just relocate/wrap
 * the existing markup so it slots in here as one of the three views).
 */
export function MasonryView({ pins }: MasonryViewProps) {
  return (
    <div className="board-masonry">
      {pins.map((pin) => (
        <div key={pin.id} className="board-masonry__item">
          <img src={pin.imageUrl} alt={pin.title} loading="lazy" />
        </div>
      ))}
    </div>
  );
}
