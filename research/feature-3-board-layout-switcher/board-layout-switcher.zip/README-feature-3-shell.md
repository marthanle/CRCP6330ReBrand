# Feature 3 Shell — Wiring Notes for Steve

This is a scaffold, not a finished feature — matches the structure in
`feature-3-board-layout-switcher-spec.md`. Everything marked `TODO (Steve)`
is an intentional gap to fill in, not an oversight.

## Files

- `BoardLayoutSwitcher.tsx` — the toggle + view-switching container. Drop
  this into wherever the board page currently renders its pin grid.
- `boardLayoutStore.ts` — localStorage read/write helpers. **Coordinate the
  `STORAGE_KEY` and blob shape with whoever's building Feature 1** — they
  should be the same object.
- `views/MasonryView.tsx` — stub; replace body with the board page's
  *existing* masonry rendering (don't rewrite it, just relocate it here).
- `views/GridView.tsx` — new; needs the sparse-row (0–2 pins) fix and the
  600px breakpoint CSS.
- `views/ListView.tsx` — new; needs the 2-line title truncation CSS.
- `types.ts` — shared `Pin` type. Adjust fields to match whatever the real
  seed dataset already uses — this is a guess based on the spec, not
  authoritative.

## Before merging, confirm

1. Does a `Pin` type/interface already exist elsewhere in the repo? If so,
   import that instead of the placeholder in `types.ts`.
2. Where does the board page currently live, and what does it currently
   pass down for pins? `BoardLayoutSwitcher` expects `boardId: string` and
   `pins: Pin[]` as props — wire those from whatever the board route/loader
   already provides.
3. Scroll-position preservation on layout switch is *not yet implemented*
   here — it's flagged with a TODO in `BoardLayoutSwitcher.tsx`. This is
   listed as a required acceptance criterion in the spec, not optional.

## Not included in this shell (per spec's Out of Scope)

- No global layout setting — per-board only, as scaffolded
- No drag-to-reorder
- No custom Grid column counts beyond 4/2 (or 1, if needed at very small
  widths per the spec)
